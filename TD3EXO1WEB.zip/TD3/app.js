document.addEventListener("DOMContentLoaded", function() {
    defTitre1();
});

function defTitre1() {
    var titreH1 = document.getElementById("titre");
    document.title = titreH1.textContent;
}

function defTitre2() {
    // Sélectionne la première balise h2
    var premiereBaliseH2 = document.querySelector('h2');

    // Vérifie si une balise h2 a été trouvée
    if (premiereBaliseH2) {
        // Récupère le texte de la première balise h2
        var texteH2 = premiereBaliseH2.textContent;

        // Définit le titre de la page avec le texte de la première balise h2
        document.title = texteH2;
    } else {
        console.error("Aucune balise h2 n'a été trouvée dans le document.");
    }
}

function defTitre3(){
    var baliseh2 = document.querySelectorAll('h2')
    if(baliseh2.length > 0){
        var texteH3 = baliseh2[baliseh2.length-1].textContent;
        document.title = texteH3;
    }else{
        document.title ="BENCHEKROUN Yasmine"
    }
}
function defTitre4() {
    // Sélectionne tous les éléments avec la classe "firstOrLast"
    var elementsFirstOrLast = document.querySelectorAll('.firstOrLast');

    // Vérifie s'il y a au moins un élément avec la classe "firstOrLast"
    if (elementsFirstOrLast.length > 0) {
        var nombreElements = elementsFirstOrLast.length;

        // Utilise le premier ou le dernier élément en fonction de la parité du nombre d'éléments
        var elementTitre = (nombreElements % 2 === 0) ? elementsFirstOrLast[0] : elementsFirstOrLast[nombreElements - 1];

        // Définit le titre de la page avec le texte de l'élément sélectionné
        document.title = elementTitre.textContent;
    } else {
        // Aucun élément avec la classe "firstOrLast", définir le titre avec nom et prénom
        document.title = "Votre Nom et Prénom";
    }
}
function inverseTexte() {
    // Sélectionne les deux balises <p>
    var p1 = document.querySelector('#ensemble1 p');
    var p2 = (document.querySelector('#ensemble2 p'));

    // Inverse le contenu des balises <p>
    var temp = p1.innerHTML;
    p1.innerHTML = p2.innerHTML;
    p2.innerHTML = temp;
}

function datemodif() {
    // Récupère la balise meta avec l'attribut name="author"
    var authorMeta = document.querySelector('meta[name="author"]');
    
    // Récupère la date actuelle
    var currentDate = new Date();

    // Construit le texte de la dernière modification
    var modifText = "Dernière modification : le " +
                    currentDate.toLocaleDateString("fr-FR", { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) +
                    " par " + (authorMeta ? authorMeta.content : "Yasmine BENCHEKROUN");

    // Affiche le texte dans la balise avec l'ID "date_modif"
    var dateModifDiv = document.getElementById('date_modif');
    dateModifDiv.textContent = modifText;
}

// Appelle la fonction au chargement de la page
document.addEventListener("DOMContentLoaded", function() {
    datemodif();
});


// Appelle la fonction au chargement de la page
document.addEventListener("DOMContentLoaded", function() {
    defTitre2();
    defTitre3();
    defTitre4();
    inverseTexte();
    datemodif();
});
